package com.walmart.homework.exceptions;


/**
 * Created by Krishna Ghatia on 4/28/2016.
 */
public class WalmartException extends Exception{

    public WalmartException(){

    }

    public WalmartException(String message){
        super(message);
    }

}
